def handler(event, context):
    print('Hello from Boeing Hot Path')
    return 200